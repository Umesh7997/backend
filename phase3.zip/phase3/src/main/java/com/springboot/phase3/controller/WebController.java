package com.springboot.phase3.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import com.springboot.phase3.model.Buynow;
import com.springboot.phase3.model.Login;
import com.springboot.phase3.model.User;
import com.springboot.phase3.model.Addbook;
import com.springboot.phase3.repo.BuynowRepository;
import com.springboot.phase3.repo.UserRepository;
import com.springboot.phase3.repo.LoginRepository;
import com.springboot.phase3.repo.AddbookRepository;
import com.springboot.phase3.rnf.ResourceNotFound;

@RestController
@CrossOrigin(origins = "http://localhost:4200")                

@RequestMapping("/api")
public class WebController {

	@Autowired
	private UserRepository userRepository;
	@Autowired
	private LoginRepository loginRepository;
	@Autowired
	private BuynowRepository buynowRepository;
	@Autowired
	private AddbookRepository addbookRepository;
	
	
	// get all users
	
	@GetMapping("/users")
	public List<User> getAllUsers(){
		return userRepository.findAll();
	}		
	
	// create user rest api
	
	@PostMapping("/save-user")
	public User createUser(@RequestBody User user) {
		return userRepository.save(user);
	}
	
	
	@GetMapping("/logins")
	public List<Login> getAllLogins(){
		return loginRepository.findAll();
	}		
	
	
	@PostMapping("/save-login")
	public Login createLogin(@RequestBody Login login) {
		return loginRepository.save(login);
	}
	
	// get all buynows
	
	@GetMapping("/buynow")
	public List<Buynow> getAllBuynows(){
		return buynowRepository.findAll();
	}		
	
	@PostMapping("/save-buynow")
	public Buynow createBuynow(@RequestBody Buynow buynow) {
	
		return buynowRepository.save(buynow);
	}
	
	
	@GetMapping("/addbook")
	public List<Addbook> getAllAddbooks(){
		return addbookRepository.findAll();
	}		
	
	@PostMapping("/save-addbook")
	public Addbook createaddbook(@RequestBody Addbook addbook) {
	
		return addbookRepository.save(addbook);
	}
	
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// get user by id rest api
	
	@GetMapping("/users/{id}")
	public ResponseEntity<User> getuserById(@PathVariable Long id) {
		User user = userRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFound("User not exist with id :" + id));
		return ResponseEntity.ok(user);
	}
	
	// get buynow by id rest api
	
		@GetMapping("/buynow/{id}")
		public ResponseEntity<Buynow> getBuynowById(@PathVariable Long id) {
			Buynow buynow = buynowRepository.findById(id)
					.orElseThrow(() -> new ResourceNotFound("Buynow not exist with id :" + id));
			return ResponseEntity.ok(buynow);
		}
		
		@GetMapping("/addbook/{id}")
		public ResponseEntity<Addbook> getAddbookById(@PathVariable Long id) {
			Addbook addbook = addbookRepository.findById(id)
					.orElseThrow(() -> new ResourceNotFound("addbook not exist with id :" + id));
			return ResponseEntity.ok(addbook);
		}
	

		@GetMapping("/loginUser/{email}/{pwd}")
		public ResponseEntity<User> getUser(@PathVariable("email") String mail,@PathVariable("pwd") String password) {
			User user= userRepository.getUser(mail,password);
		System.out.println("login with email");
		return ResponseEntity.ok(user);
		}
		
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	// update user rest api
	
	@PutMapping("/users/{id}")
	public ResponseEntity<User> updateUser(@PathVariable Long id, @RequestBody User userDetails){
		User user = userRepository.findById(id)
				.orElseThrow();
		
		user.setFirstName(userDetails.getFirstName());
		user.setLastName(userDetails.getLastName());
		user.setGender(userDetails.getGender());
		user.setEmailId(userDetails.getEmailId());
		user.setPassword(userDetails.getPassword());
		
		User updatedUser = userRepository.save(user);
		return ResponseEntity.ok(updatedUser);
	}
	
	//update buynow rest api
	
	@PutMapping("/buynow/{id}")
	public ResponseEntity<Buynow> createBuyer(@PathVariable Long id, @RequestBody Buynow buynowDetails){
		Buynow buynow = buynowRepository.findById(id)
				.orElseThrow();
		
		buynow.setBookName(buynowDetails.getBookName());
		buynow.setUserName(buynowDetails.getUserName());
		buynow.setEmailId(buynowDetails.getEmailId());
		buynow.setPrice(buynowDetails.getPrice());
		buynow.setPhoneNumber(buynowDetails.getPhoneNumber());
		buynow.setAddress(buynowDetails.getAddress());
		buynow.setOrderDate(buynowDetails.getOrderDate());
		buynow.setState(buynowDetails.getState());
		buynow.setCity(buynowDetails.getCity());
		buynow.setZipCode(buynowDetails.getZipCode());
		
		Buynow updatedBuynow = buynowRepository.save(buynow);
		return ResponseEntity.ok(updatedBuynow);
	}
	
	
	@PutMapping("/addbook/{id}")
	public ResponseEntity<Addbook> updateAddbook(@PathVariable Long id, @RequestBody Addbook addbookDetails){
		Addbook addbook = addbookRepository.findById(id)
				.orElseThrow();
		
		addbook.setBookName(addbookDetails.getBookName());
		addbook.setImage(addbookDetails.getImage());
		addbook.setPrice(addbookDetails.getPrice());
		addbook.setDescription(addbookDetails.getDescription());
		
		Addbook updatedAddbook = addbookRepository.save(addbook);
		return ResponseEntity.ok(updatedAddbook);
	}
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	// delete user rest api
	
	@DeleteMapping("/users/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteUser(@PathVariable Long id){
		User user = userRepository.findById(id)
				.orElseThrow();
		
		userRepository.delete(user);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	

	// delete buynow rest api
	
	@DeleteMapping("/buynow/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteBuynow(@PathVariable Long id){
		Buynow buynow = buynowRepository.findById(id)
				.orElseThrow();
		
		buynowRepository.delete(buynow);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
	
	@DeleteMapping("/logins/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteLogin(@PathVariable Long id){
		Login login = loginRepository.findById(id)
				.orElseThrow();
		
		loginRepository.delete(login);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
	
	@DeleteMapping("/addbook/{id}")
	public ResponseEntity<Map<String, Boolean>> deleteAddbook(@PathVariable Long id){
		Addbook addbook = addbookRepository.findById(id)
				.orElseThrow();
		
		addbookRepository.delete(addbook);
		Map<String, Boolean> response = new HashMap<>();
		response.put("deleted", Boolean.TRUE);
		return ResponseEntity.ok(response);
	}
}






