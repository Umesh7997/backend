package com.springboot.phase3.repo;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.springboot.phase3.model.Login;

@Repository
public interface LoginRepository extends JpaRepository<Login, Long>{

	

	Optional<Login> findById(Long id);
	
	@Transactional(timeout = 300)
	@Query(nativeQuery = true, value = "SELECT * FROM login WHERE email_id =?1")
	public Login findByEmail_id(@Param("email_id") String email_id);

}