package com.springboot.phase3.repo;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;


import org.springframework.stereotype.Repository;


import com.springboot.phase3.model.Addbook;

@Repository
public interface AddbookRepository extends JpaRepository<Addbook, Long>{

	

	Optional<Addbook> findById(Long id);
	

}