package com.springboot.phase3.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "books") 
public class Addbook {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "book_name")                   
	private String bookName;

	@Column(name = "image")                      
	private String image;
	
	
	@Column(name = "price")                       
	private String price;
	
	
	@Column(name = "description")                       
	private String description;
	

	
	public Addbook() {
		
	}
	public long getId() {                              
		return id;
	}
	public void setId(long id) {                      
		this.id = id;
	}
	public String getBookName() {                    
		return bookName;
	}
	public void setBookName(String bookName) {         
		this.bookName = bookName;
	}
	public String getImage() {                      
		return image;
	}
	public void setImage(String image) {          
		this.image = image;
	}
	
	public String getPrice() {                        
		return price;
	}
	public void setPrice(String price) {             
		this.price = price;
	}
	public String getDescription() {                        
		return description;
	}
	public void setDescription(String description) {             
		this.description = description;
	}

	
}
