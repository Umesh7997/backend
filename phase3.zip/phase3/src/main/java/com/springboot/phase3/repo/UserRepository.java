package com.springboot.phase3.repo;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.springboot.phase3.model.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long>{

	

	Optional<User> findById(Long id);
	
	@Transactional(timeout = 300)
	@Query(nativeQuery = true, value = "SELECT * FROM USERS WHERE email_id=:email and password=:pwd")
	public User getUser(@Param("email") String user,@Param("pwd") String pwd);

}