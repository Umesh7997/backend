package com.springboot.phase3.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "login") 
public class Login {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;
	
	@Column(name = "email_id")                       
	private String emailId;

	@Column(name = "password")                      
	private String password;
	
	
	public Login() {
		
	}
	public long getId() {                              
		return id;
	}
	public void setId(long id) {                      
		this.id = id;
	}
	
	public String getEmailId() {                        
		return emailId;
	}
	public void setEmailId(String emailId) {             
		this.emailId = emailId;
	}

public String getPassword() {                        
		return password;
	}
	public void setPassword(String password) {             
		this.password = password;
	}

}


